<?php
/*
Plugin Name: ShareBlock Function
Description: Function and options for shareblock
Plugin URI: http://jellywp.com/wp/shareblock/
Author: Jellywp
Author URI: http://themeforest.net/user/jellywp
Version: 1.6
License: GPL2
Text Domain: shareblock-function
*/
if ( ! defined( 'ABSPATH' ) ) exit;
function shareblock_lang() {
    load_plugin_textdomain( 'shareblock-function', FALSE, dirname( plugin_basename( __FILE__ ) ) . 'languages/' );
}
add_action( 'init', 'shareblock_lang' );
require_once plugin_dir_path( __FILE__ ).'block/elementor.php';
require_once plugin_dir_path( __FILE__ ).'inc/core.php';
require_once plugin_dir_path( __FILE__ ).'inc/custom-fonts-taxonomy.php';
require_once plugin_dir_path( __FILE__ ).'inc/custom-fonts.php';
require_once plugin_dir_path( __FILE__ ).'inc/cus-metabox.php';
require_once plugin_dir_path( __FILE__ ).'/inc/metas.php';
require_once plugin_dir_path( __FILE__ ).'/inc/sb.php';
require_once plugin_dir_path( __FILE__ ).'/inc/function/init.php';
require_once plugin_dir_path( __FILE__ ).'/widget/social_counter.php';
require_once plugin_dir_path( __FILE__ ).'/widget/recent-large.php';
require_once plugin_dir_path( __FILE__ ).'/widget/about-us.php';
require_once plugin_dir_path( __FILE__ ).'/widget/recent-small.php';
require_once plugin_dir_path( __FILE__ ).'/widget/recent-number.php';
require_once plugin_dir_path( __FILE__ ).'/widget/slider-post.php';
require_once plugin_dir_path( __FILE__ ).'/widget/category-widget.php';
require_once plugin_dir_path( __FILE__ ).'/widget/contact-form-7.php';
require_once plugin_dir_path( __FILE__ ).'/widget/author.php';