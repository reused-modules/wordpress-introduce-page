<?php
namespace shareblockElementor\Widgets;
use Elementor\Widget_Base;
use Elementor\Controls_Manager;
use Elementor\Group_Control_Image_Size;
use Elementor\Group_Control_Typography;
use Elementor\Schemes\Color;
use Elementor\Schemes\Typography;
use Elementor\Utils;
use Elementor\Control_Media;
use Elementor\Group_Control_Border;
use Elementor\Group_Control_Box_Shadow;
use Elementor\Group_Control_Text_Shadow;
use Elementor\Group_Control_Background;
use Elementor\Repeater;
use Elementor\Icons_Manager;
if ( ! defined( 'ABSPATH' ) ) exit;

class shareblock_grid_post extends Widget_Base {

  public $base;

    public function get_name() {
        return 'shareblock-grid-post';
    }

    public function get_title() {
        return esc_html__( 'Grid Post', 'shareblock-function' );
    }

    public function get_icon() { 
        return 'eicon-gallery-justified jl-icons';
    }

    public function get_categories() {
       return [ 'shareblock-elements' ];
    }

    protected function register_controls() {

        $this->start_controls_section(
            'section_tab',
            [
                'label' => esc_html__('Post Query And Setting', 'shareblock-function'),
            ]
        );

        $this->add_control(
      'section_title', [
        'label'       => esc_html__( 'Section Title', 'shareblock-function' ),
        'default'   => 'Grid Post Layout',
        'type'        => Controls_Manager::TEXT,
        'label_block'   => true,
        'placeholder'    => esc_html__( 'Section text', 'shareblock-function' )        
      ]
      );

        $this->add_control(
      'section_sub_title', [
        'label'       => esc_html__( 'Section Sub Title', 'shareblock-function' ),
        'default'   => 'This is an optional subtitle for post section',
        'type'        => Controls_Manager::TEXT,
        'label_block'   => true
      ]
      );

        $this->add_control(
            'categories',
            [
                'label' =>esc_html__('Select Categories', 'shareblock-function'),
                'type'      => Controls_Manager::SELECT2,
                 'options'   => $this->post_categories(),
                'label_block' => true,
                'multiple'  => true,
            ]
        ); 
         

        $this->add_control(
      'tags', [
        'label'       => esc_html__( 'Tag Slug', 'shareblock-function' ),
        'description' => esc_html__( 'Example: tagslug1,tagslug2,tagslug3', 'shareblock-function' ),
        'type'        => Controls_Manager::TEXT,
        'label_block'   => true
      ]
      );  

        $this->add_control(
            'author',
            [
                'label' =>esc_html__('Author Filter', 'shareblock-function'),
                'type'      => Controls_Manager::SELECT,
                'default'   => 'none',
                 'options'   => $this->post_author(),
            ]
        );  
               

        $this->add_control(
      'posts_per_page',
      array(
        'label'       => esc_html__( 'Posts per Page', 'shareblock-function' ),
        'type'        => Controls_Manager::NUMBER,
        'default'     => '6'
      )
    );

        $this->add_control(
      'offset',
      array(
        'label'       => esc_html__( 'Post Offset', 'shareblock-function' ),
        'type'        => Controls_Manager::NUMBER,
        'default'     => '',
      )
    );
    

    $this->add_control(
      'format',
      array(
        'label'       => esc_html__( 'Post Format', 'shareblock-function' ),
        'type'        => Controls_Manager::SELECT,
        'options'   => [
                        '0'               => esc_html__( 'All', 'shareblock-function' ),
                        'gallery'        => esc_html__( 'Gallery', 'shareblock-function' ),
                        'video'        => esc_html__( 'Video', 'shareblock-function' ),
                        'audio'        => esc_html__( 'Audio', 'shareblock-function' ),
                        'quote'        => esc_html__( 'Quote', 'shareblock-function' ),
                    ],
        'default'     => '0',
      )
    );       

    $this->add_control(
      'post_not_in', [
        'label'       => esc_html__( 'Exclude Post IDs', 'shareblock-function' ),
          'description' => esc_html__( 'Example: 1,2,3', 'shareblock-function' ),
          'default'     => '',
        'type'        => Controls_Manager::TEXT,
        'label_block'   => true
      ]
      );   

      $this->add_control(
      'post_in', [
        'label'       => esc_html__( 'Post IDs Filter', 'shareblock-function' ),
          'description' => esc_html__( 'Example: 1,2,3', 'shareblock-function' ),
          'default'     => '',
        'type'        => Controls_Manager::TEXT,
        'label_block'   => true
      ]
      );    

      $this->add_control(
            'order',
            [
                'label'     =>esc_html__( 'Sort Order', 'shareblock-function' ),
                'type'      => Controls_Manager::SELECT,
                'default'   => 'date_post',
                'options'   => [
                        'date_post'      => esc_html__( 'Latest Post', 'shareblock-function' ),
                        'rand'      => esc_html__( 'Random', 'shareblock-function' ),
                        'author'      => esc_html__( 'Author', 'shareblock-function' ),
                        'alphabetical_order_decs'      => esc_html__( 'Title DECS', 'shareblock-function' ),
                        'alphabetical_order_asc'      => esc_html__( 'Title ACS', 'shareblock-function' ),
                    ],
            ]
        );          
      $this->add_control(
      'tabs_link',
      array(
        'label'       => esc_html__( 'Tab Link', 'shareblock-function' ),
        'type'        => Controls_Manager::SELECT,
        'default'   => 'none',
        'options'   => [
                        'none'     => esc_html__( 'None', 'shareblock-function' ),
                        'category' => esc_html__( 'Categories', 'shareblock-function' ),
                        'tag'      => esc_html__( 'Tags', 'shareblock-function' ),                        
                    ],
      )
    );
    $this->add_control(
      'tabs_link_ids',
      array(
        'label'       => esc_html__( 'Filter ID', 'shareblock-function' ),
        'type'        => Controls_Manager::TEXT,
        'description' => esc_html__( 'Add ID of category or tag (Example: 1,2,3)', 'shareblock-function' ),
        'default'     => '',
      )
    );
    $this->add_control(
      'tabs_link_label',
      array(
        'label'       => esc_html__( 'Tab Label', 'shareblock-function' ),
        'type'        => Controls_Manager::TEXT,
        'default'     => esc_html__( 'All', 'shareblock-function' ),
      )
    );      
      $this->add_control(
      'pagination',
      array(
        'label'       => esc_html__( 'Pagination', 'shareblock-function' ),
        'type'        => Controls_Manager::SELECT,
        'options'   => [
                        '0'               => esc_html__( 'None', 'shareblock-function' ),
                        'next_prev'       => esc_html__( 'Arrow', 'shareblock-function' ),
                        'loadmore'        => esc_html__( 'Load More', 'shareblock-function' ),
                        'autoload'        => esc_html__( 'Auto Load', 'shareblock-function' ),
                    ],
        'default'     => '0',
      )
    );      

        

        $this->end_controls_section();

     $this->start_controls_section(
      'section_tab_header', [
        'label'  => esc_html__( 'Section header', 'shareblock-function' ),
        'tab'     => Controls_Manager::TAB_STYLE,
      ]
        ); 

     $this->add_control(
            'title_style',
            [
                'label'     =>esc_html__( 'Section Title Styles', 'shareblock-function' ),
                'type'      => Controls_Manager::SELECT,
                'default'   => 'sec_style1',
                'options'   => [
                        'sec_style1'      =>esc_html__( 'Style 1', 'shareblock-function' ),
                        'sec_style2'    =>esc_html__( 'Style 2', 'shareblock-function' ),
                        'sec_style3'    =>esc_html__( 'Style 3', 'shareblock-function' ),
                        'sec_style4'    =>esc_html__( 'Style 4', 'shareblock-function' ),
                    ],
            ]
        );
     $this->add_control(
            'title_font',
            [
                'label'     =>esc_html__( 'Section Title Font', 'shareblock-function' ),
                'type'      => Controls_Manager::SELECT,
                'default'   => 'font_style1',
                'options'   => [
                        'font_style1'      =>esc_html__( 'Menu Font', 'shareblock-function' ),
                        'font_style2'    =>esc_html__( 'Title Font', 'shareblock-function' ),
                        'font_style3'    =>esc_html__( 'Paragraph Font', 'shareblock-function' ),                        
                    ],
            ]
        );  
      $this->add_responsive_control(
        'sec_font_size',
        [
            'label' => __( 'Title font size', 'shareblock-function' ),
            'type' => Controls_Manager::SLIDER,            
            'range' => [
                'px' => [
                    'min' => 1,
                    'max' => 200,
                    'step' => 1,
                ]
            ],
            'selectors' => [
            '{{WRAPPER}} .jl_sec_title h3' => 'font-size: {{SIZE}}{{UNIT}};',
            ],
        ]
    );
    $this->add_responsive_control(
        'sec_letter_spaceing',
        [
            'label' => __( 'Title letter spacing', 'shareblock-function' ),
            'type' => Controls_Manager::SLIDER,            
            'range' => [
                'px' => [
                    'min' => 0,
                    'max' => 200,
                    'step' => 1,
                ]
            ],
            'selectors' => [
            '{{WRAPPER}} .jl_sec_title h3' => 'letter-spacing: {{SIZE}}{{UNIT}} !important;',
            ],
        ]
    );
    $this->add_control(
      'title_color',
      [
        'label' => __( 'Title color', 'shareblock-function' ),
        'type' => \Elementor\Controls_Manager::COLOR,        
        'selectors' => [
          '{{WRAPPER}} .jl_sec_title h3' => 'color: {{VALUE}}',
        ],
      ]
    );
    $this->add_control(
      'title_bgcolor',
      [
        'label' => __( 'Title background color', 'shareblock-function' ),
        'type' => \Elementor\Controls_Manager::COLOR,        
        'selectors' => [
          '{{WRAPPER}} .jl_sec_title.sec_style2 .jl_title_c span:before' => 'background-color: {{VALUE}}',
        ],
      ]
    );
    $this->add_control(
      'sub_title_color',
      [
        'label' => __( 'Sub title color', 'shareblock-function' ),
        'type' => \Elementor\Controls_Manager::COLOR,        
        'selectors' => [
          '{{WRAPPER}} .jl_sec_title p' => 'color: {{VALUE}}',
        ],
      ]
    );
    $this->add_control(
      'line_color',
      [
        'label' => __( 'Line color', 'shareblock-function' ),
        'type' => \Elementor\Controls_Manager::COLOR,
        'selectors' => [
          '{{WRAPPER}} .jl_sec_title .jl_title_c:before, {{WRAPPER}} .jl_sec_title .jl_title_c:after' => 'border-top: 1px solid {{VALUE}}',
        ],
      ]
    );
    $this->add_control(
      'section_align',
      [
        'label' => __( 'Alignment', 'shareblock-function' ),
        'type' => \Elementor\Controls_Manager::CHOOSE,
        'options' => [
          'left' => [
            'title' => __( 'Left', 'shareblock-function' ),
            'icon' => 'fa fa-align-left',
          ],
          'center' => [
            'title' => __( 'Center', 'shareblock-function' ),
            'icon' => 'fa fa-align-center',
          ],
          'right' => [
            'title' => __( 'Right', 'shareblock-function' ),
            'icon' => 'fa fa-align-right',
          ],
        ],
        'default' => 'center',
        'toggle' => true,
        'selectors' => [
                '{{WRAPPER}} .jl_sec_title' => 'text-align: {{VALUE}}',
            ],
      ]
    );

    $this->add_control(
            'section_upercase',
            [
                'label' => esc_html__('Title Upercase', 'shareblock-function'),
                'type' => Controls_Manager::SWITCHER,
                'label_on' => esc_html__('Yes', 'shareblock-function'),
                'label_off' => esc_html__('No', 'shareblock-function'),
                'selectors'  => [
               '{{WRAPPER}} .jl_sec_title h3' => 'text-transform: uppercase !important;',               
        ],
            ]
        );      
    
     $this->end_controls_section();
     

    $this->start_controls_section(
      'section_tab_style', [
        'label'  => esc_html__( 'Post Custom Style', 'shareblock-function' ),
        'tab'     => Controls_Manager::TAB_STYLE,
      ]
        );  

    $this->add_control(
      'g_style',
      array(
        'label'       => esc_html__( 'Grid Style', 'shareblock-function' ),
        'type'        => Controls_Manager::SELECT,
        'options'   => [
                        'jl_mgrid'               => esc_html__( 'Grid Style 1', 'shareblock-function' ),
                        'jl_captext'        => esc_html__( 'Grid Style 2', 'shareblock-function' ),                        
                        'jl_sqgrid'        => esc_html__( 'Grid Style 3', 'shareblock-function' ),                        
                        'jl_numcap'        => esc_html__( 'Grid Style 4', 'shareblock-function' ),                        
                    ],
        'default'     => 'jl_mgrid',
      )
    );

        $this->add_control(
      'g_cols',
      array(
        'label'       => esc_html__( 'Post Columns', 'shareblock-function' ),
        'type'        => Controls_Manager::SELECT,
        'options'   => [
                        'g_2col'               => esc_html__( '2 cols', 'shareblock-function' ),
                        'g_3col'        => esc_html__( '3 cols', 'shareblock-function' ),
                        'g_4col'        => esc_html__( '4 cols', 'shareblock-function' ),
                        'g_5col'        => esc_html__( '5 cols', 'shareblock-function' ),
                        'g_6col'        => esc_html__( '6 cols', 'shareblock-function' ),
                    ],
        'default'     => 'g_3col',
      )
    );    
 
      $this->add_responsive_control(
        'g_font_size',
        [
            'label' => __( 'Title font size', 'shareblock-function' ),
            'type' => Controls_Manager::SLIDER,
            'default' => [
                'size' => 23,
            ],
            'range' => [
                'px' => [
                    'min' => 1,
                    'max' => 200,
                    'step' => 1,
                ]
            ],
            'selectors' => [
            '{{WRAPPER}} .jl_grid_w .text-box h3' => 'font-size: {{SIZE}}{{UNIT}};',
            ],
        ]
    ); 

    $this->add_responsive_control(
        'g_spaceing',
        [
            'label' => __( 'Grid spacing', 'shareblock-function' ),
            'type' => Controls_Manager::SLIDER,
            'default' => [
                'size' => 15,
            ],
            'range' => [
                'px' => [
                    'min' => 1,
                    'max' => 200,
                    'step' => 1,
                ]
            ],
            'selectors' => [
            '{{WRAPPER}} .jl_grid_wrap_f .jl-col3 .jl-grid-cols' => 'padding:0px {{SIZE}}{{UNIT}};',
            '{{WRAPPER}} .jl_grid_wrap_f .jl-roww' => 'margin-right: -{{SIZE}}{{UNIT}}; margin-left: -{{SIZE}}{{UNIT}};',
            '{{WRAPPER}} .jl_grid_overlay .jl_sec_title' => 'padding:0px {{SIZE}}{{UNIT}};',
            ],
        ]
    ); 
    $this->add_responsive_control(
        'g_margin',
        [
            'label' => __( 'Grid Margin', 'shareblock-function' ),
            'type' => Controls_Manager::SLIDER,
            'default' => [
                'size' => 30,
            ],
            'range' => [
                'px' => [
                    'min' => 1,
                    'max' => 200,
                    'step' => 1,
                ]
            ],
            'selectors' => [
            '{{WRAPPER}} .jl_grid_w' => 'margin-bottom: {{SIZE}}{{UNIT}};',            
            ],
        ]
    ); 

    $this->add_responsive_control(
        'g_pagination',
        [
            'label' => __( 'Pagination spacing', 'shareblock-function' ),
            'type' => Controls_Manager::SLIDER,
            'default' => [
                'size' => 30,
            ],
            'range' => [
                'px' => [
                    'min' => -50,
                    'max' => 200,
                    'step' => 1,
                ]
            ],
            'selectors' => [
            '{{WRAPPER}} .jl_lmore_wrap' => 'margin-top: {{SIZE}}{{UNIT}};',            
            ],
        ]
    ); 

    $this->add_responsive_control(
        'g_pagination_radius',
        [
            'label' => __( 'Pagination broder radius', 'shareblock-function' ),
            'type' => Controls_Manager::SLIDER,
            'default' => [
                'size' => 0,
            ],
            'range' => [
                'px' => [
                    'min' => 0,
                    'max' => 200,
                    'step' => 1,
                ]
            ],
            'selectors' => [
            '{{WRAPPER}} .jl_lmore_c' => 'border-radius: {{SIZE}}{{UNIT}};',            
            ],
        ]
    );    

      $this->add_control(
            'hide_format',
            [
                'label' => esc_html__('Hide post format', 'shareblock-function'),
                'type' => Controls_Manager::SWITCHER,
                'label_on' => esc_html__('Yes', 'shareblock-function'),
                'label_off' => esc_html__('No', 'shareblock-function'),
                'selectors'  => [
               '{{WRAPPER}} .jl_grid_w .jl_post_type_icon' => 'display: none;',               
        ],
            ]
        );

      $this->add_control(
            'show_excep',
            [
                'label' => esc_html__('Hide Exception', 'shareblock-function'),
                'type' => Controls_Manager::SWITCHER,
            'selectors'  => [

               '{{WRAPPER}} .jl_grid_w .text-box p' => 'display:none;',
        ]
        ]
        );   
         
        $this->end_controls_section();
    }

    protected function render( ) { 
        $settings = $this->get_settings();

      if ( function_exists( 'shareblock_mgrid' ) ) {
      $settings['blockid'] = 'blockid_' . $this->get_id();      
      if(!empty($settings['categories'])){
      $settings['categories'] = implode(',', $settings['categories']);      
      }
      echo \shareblock_mgrid( $settings );
      }
    }

    public function post_categories() {

      $terms = get_terms( array(
            'taxonomy'    => 'category',
            'hide_empty'  => false,
            'posts_per_page' => -1, 
            'suppress_filters' => false,
      ) );

      $cat_list = [];
      foreach($terms as $post) {
      $cat_list[$post->term_id]  = [$post->name];
      }
      return $cat_list;
   }

   public function post_author() {

    $blogusers = get_users( array(
    'role__not_in' => array( 'subscriber' ),
    'fields'       => array( 'ID', 'display_name' )
    ) );

      $user_list = [];
      $user_list['none']= esc_html__( 'None', 'shareblock-function' );
      foreach($blogusers as $user) {
      $user_list[$user->ID]  = [$user->display_name];
      }
      return $user_list;
   }

}