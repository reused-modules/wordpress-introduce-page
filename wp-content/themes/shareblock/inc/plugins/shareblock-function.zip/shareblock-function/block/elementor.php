<?php
namespace shareblockElementor;
use Elementor\Widget_Base;
if ( ! defined( 'ABSPATH' ) ) exit;

if(defined('ELEMENTOR_VERSION')):

class shareblock_Shortcode{	
    public static $_instance;
    public $localize_data = array();
	public function __construct(){

		add_action('elementor/init', array($this, 'shareblock_elementor_init'));
        add_action( 'elementor/widgets/register', array( $this, 'shareblock_shortcode_elements' ), 1 );        
        add_action( 'elementor/editor/after_enqueue_styles', array( $this, 'editor_enqueue_styles' ) );
        add_action( 'elementor/frontend/before_enqueue_scripts', array( $this, 'enqueue_scripts' ) );
        add_action( 'elementor/preview/enqueue_styles', array( $this, 'preview_enqueue_scripts' ) );
        
	}
    
    public function enqueue_scripts() {}

    public function editor_enqueue_styles() {}

    public function preview_enqueue_scripts() {}

    public function shareblock_elementor_init(){
    
        \Elementor\Plugin::$instance->elements_manager->add_category(
            'shareblock-elements',
            [
                'title' =>esc_html__( 'Shareblock Function', 'shareblock-function' ),
                'icon' => 'fa fa-plug',
            ],
            1
        );
    }

    public function shareblock_shortcode_elements(){
      
      // require_once 'section-title.php';
      // \Elementor\Plugin::instance()->widgets_manager->register( new Widgets\shareblock_section_title());      
      require_once 'feature-box.php';
      \Elementor\Plugin::instance()->widgets_manager->register( new Widgets\shareblock_feature_box());      
      require_once 'feature-right-list.php';
      \Elementor\Plugin::instance()->widgets_manager->register( new Widgets\shareblock_feature_right_list());      
      require_once 'feature-slider.php';
      \Elementor\Plugin::instance()->widgets_manager->register( new Widgets\shareblock_feature_slider());      
      require_once 'feature-carousel.php';
      \Elementor\Plugin::instance()->widgets_manager->register( new Widgets\shareblock_feature_carousel());      
      require_once 'large-post.php';
      \Elementor\Plugin::instance()->widgets_manager->register( new Widgets\shareblock_large_post());
      require_once 'grid-post.php';
      \Elementor\Plugin::instance()->widgets_manager->register( new Widgets\shareblock_grid_post());
      require_once 'grid-overlay.php';
      \Elementor\Plugin::instance()->widgets_manager->register( new Widgets\shareblock_grid_overlay());            
      require_once 'list-post.php';
      \Elementor\Plugin::instance()->widgets_manager->register( new Widgets\shareblock_list_post());
      require_once 'small-list-post.php';
      \Elementor\Plugin::instance()->widgets_manager->register( new Widgets\shareblock_small_list());            
      require_once 'xsmall-list-post.php';
      \Elementor\Plugin::instance()->widgets_manager->register( new Widgets\shareblock_xsmall_list());            
      require_once 'masonry-post.php';
      \Elementor\Plugin::instance()->widgets_manager->register( new Widgets\shareblock_masonry_post());      
      
    }
    
	public static function shareblock_get_instance() {
        if (!isset(self::$_instance)) {
            self::$_instance = new shareblock_Shortcode();
        }
        return self::$_instance;
    }

}
$shareblock_Shortcode = shareblock_Shortcode::shareblock_get_instance();

endif;