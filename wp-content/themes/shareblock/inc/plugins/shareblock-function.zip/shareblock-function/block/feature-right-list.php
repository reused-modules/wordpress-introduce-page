<?php
namespace shareblockElementor\Widgets;
use Elementor\Widget_Base;
use Elementor\Controls_Manager;
use Elementor\Group_Control_Image_Size;
use Elementor\Group_Control_Typography;
use Elementor\Schemes\Color;
use Elementor\Schemes\Typography;
use Elementor\Utils;
use Elementor\Control_Media;
use Elementor\Group_Control_Border;
use Elementor\Group_Control_Box_Shadow;
use Elementor\Group_Control_Text_Shadow;
use Elementor\Group_Control_Background;
use Elementor\Repeater;
use Elementor\Icons_Manager;
if ( ! defined( 'ABSPATH' ) ) exit;

class shareblock_feature_right_list extends Widget_Base {

  public $base;

    public function get_name() {
        return 'shareblock-feature-right-list';
    }

    public function get_title() {
        return esc_html__( 'Feature Header', 'shareblock-function' );
    }

    public function get_icon() { 
        return 'eicon-gallery-justified jl-icons';
    }

    public function get_categories() {
       return [ 'shareblock-elements' ];
    }

    protected function register_controls() {

    $this->start_controls_section(
            'section_tab',
            [
                'label' => esc_html__('Post Query And Setting', 'shareblock-function'),
            ]
        );

        $this->add_control(
      'section_title', [
        'label'       => esc_html__( 'Section Title', 'shareblock-function' ),
        'type'        => Controls_Manager::TEXT,
        'label_block'   => true,
        'placeholder'    => esc_html__( 'Section text', 'shareblock-function' )        
      ]
      );

        $this->add_control(
      'section_sub_title', [
        'label'       => esc_html__( 'Section Sub Title', 'shareblock-function' ),
        'type'        => Controls_Manager::TEXT,
        'label_block'   => true
      ]
      );

        $this->add_control(
            'categories',
            [
                'label' =>esc_html__('Select Categories', 'shareblock-function'),
                'type'      => Controls_Manager::SELECT2,
                 'options'   => $this->post_categories(),
                'label_block' => true,
                'multiple'  => true,
            ]
        ); 
         

        $this->add_control(
      'tags', [
        'label'       => esc_html__( 'Tag Slug', 'shareblock-function' ),
        'description' => esc_html__( 'Example: tagslug1,tagslug2,tagslug3', 'shareblock-function' ),
        'type'        => Controls_Manager::TEXT,
        'label_block'   => true
      ]
      );  

        $this->add_control(
            'author',
            [
                'label' =>esc_html__('Author Filter', 'shareblock-function'),
                'type'      => Controls_Manager::SELECT,
                'default'   => 'none',
                 'options'   => $this->post_author(),
            ]
        );                        

        $this->add_control(
      'offset',
      array(
        'label'       => esc_html__( 'Post Offset', 'shareblock-function' ),
        'type'        => Controls_Manager::NUMBER,
        'default'     => '',
      )
    );
    

    $this->add_control(
      'format',
      array(
        'label'       => esc_html__( 'Post Format', 'shareblock-function' ),
        'type'        => Controls_Manager::SELECT,
        'options'   => [
                        '0'               => esc_html__( 'All', 'shareblock-function' ),
                        'gallery'        => esc_html__( 'Gallery', 'shareblock-function' ),
                        'video'        => esc_html__( 'Video', 'shareblock-function' ),
                        'audio'        => esc_html__( 'Audio', 'shareblock-function' ),
                        'quote'        => esc_html__( 'Quote', 'shareblock-function' ),
                    ],
        'default'     => '0',
      )
    );        

    $this->add_control(
      'post_not_in', [
        'label'       => esc_html__( 'Exclude Post IDs', 'shareblock-function' ),
          'description' => esc_html__( 'Example: 1,2,3', 'shareblock-function' ),
          'default'     => '',
        'type'        => Controls_Manager::TEXT,
        'label_block'   => true
      ]
      );   

      $this->add_control(
      'post_in', [
        'label'       => esc_html__( 'Post IDs Filter', 'shareblock-function' ),
          'description' => esc_html__( 'Example: 1,2,3', 'shareblock-function' ),
          'default'     => '',
        'type'        => Controls_Manager::TEXT,
        'label_block'   => true
      ]
      );    

      $this->add_control(
            'order',
            [
                'label'     =>esc_html__( 'Sort Order', 'shareblock-function' ),
                'type'      => Controls_Manager::SELECT,
                'default'   => 'date_post',
                'options'   => [
                        'date_post'      =>esc_html__( 'Latest Post', 'shareblock-function' ),
                        'rand'      =>esc_html__( 'Random', 'shareblock-function' ),
                        'author'      =>esc_html__( 'Author', 'shareblock-function' ),
                        'alphabetical_order_decs'      =>esc_html__( 'Title DECS', 'shareblock-function' ),
                        'alphabetical_order_asc'      =>esc_html__( 'Title ACS', 'shareblock-function' ),
                    ],
            ]
        );          

        

        $this->end_controls_section();

     $this->start_controls_section(
      'section_tab_header', [
        'label'  => esc_html__( 'Section header', 'shareblock-function' ),
        'tab'     => Controls_Manager::TAB_STYLE,
      ]
        ); 

     $this->add_control(
            'title_style',
            [
                'label'     =>esc_html__( 'Section Title Styles', 'shareblock-function' ),
                'type'      => Controls_Manager::SELECT,
                'default'   => 'sec_style1',
                'options'   => [
                        'sec_style1'      =>esc_html__( 'Style 1', 'shareblock-function' ),
                        'sec_style2'    =>esc_html__( 'Style 2', 'shareblock-function' ),
                        'sec_style3'    =>esc_html__( 'Style 3', 'shareblock-function' ),
                        'sec_style4'    =>esc_html__( 'Style 4', 'shareblock-function' ),
                    ],
            ]
        );
     $this->add_control(
            'title_font',
            [
                'label'     =>esc_html__( 'Section Title Font', 'shareblock-function' ),
                'type'      => Controls_Manager::SELECT,
                'default'   => 'font_style1',
                'options'   => [
                        'font_style1'      =>esc_html__( 'Menu Font', 'shareblock-function' ),
                        'font_style2'    =>esc_html__( 'Title Font', 'shareblock-function' ),
                        'font_style3'    =>esc_html__( 'Paragraph Font', 'shareblock-function' ),
                    ],
            ]
        );  
      $this->add_responsive_control(
        'sec_font_size',
        [
            'label' => __( 'Title font size', 'shareblock-function' ),
            'type' => Controls_Manager::SLIDER,            
            'range' => [
                'px' => [
                    'min' => 1,
                    'max' => 200,
                    'step' => 1,
                ]
            ],
            'selectors' => [
            '{{WRAPPER}} .jl_sec_title h3' => 'font-size: {{SIZE}}{{UNIT}};',
            ],
        ]
    );
    $this->add_responsive_control(
        'sec_letter_spaceing',
        [
            'label' => __( 'Title letter spacing', 'shareblock-function' ),
            'type' => Controls_Manager::SLIDER,            
            'range' => [
                'px' => [
                    'min' => 0,
                    'max' => 200,
                    'step' => 1,
                ]
            ],
            'selectors' => [
            '{{WRAPPER}} .jl_sec_title h3' => 'letter-spacing: {{SIZE}}{{UNIT}} !important;',
            ],
        ]
    );
    $this->add_control(
      'title_color',
      [
        'label' => __( 'Title color', 'shareblock-function' ),
        'type' => \Elementor\Controls_Manager::COLOR,        
        'selectors' => [
          '{{WRAPPER}} .jl_sec_title h3' => 'color: {{VALUE}}',
        ],
      ]
    );
    $this->add_control(
      'title_bgcolor',
      [
        'label' => __( 'Title background color', 'shareblock-function' ),
        'type' => \Elementor\Controls_Manager::COLOR,        
        'selectors' => [
          '{{WRAPPER}} .jl_sec_title.sec_style2 .jl_title_c span:before' => 'background-color: {{VALUE}}',
        ],
      ]
    );
    $this->add_control(
      'sub_title_color',
      [
        'label' => __( 'Sub title color', 'shareblock-function' ),
        'type' => \Elementor\Controls_Manager::COLOR,        
        'selectors' => [
          '{{WRAPPER}} .jl_sec_title p' => 'color: {{VALUE}}',
        ],
      ]
    );
    $this->add_control(
      'line_color',
      [
        'label' => __( 'Line color', 'shareblock-function' ),
        'type' => \Elementor\Controls_Manager::COLOR,
        'selectors' => [
          '{{WRAPPER}} .jl_sec_title .jl_title_c:before, {{WRAPPER}} .jl_sec_title .jl_title_c:after' => 'border-top: 1px solid {{VALUE}}',
        ],
      ]
    );
    $this->add_control(
      'section_align',
      [
        'label' => __( 'Alignment', 'shareblock-function' ),
        'type' => \Elementor\Controls_Manager::CHOOSE,
        'options' => [
          'left' => [
            'title' => __( 'Left', 'shareblock-function' ),
            'icon' => 'fa fa-align-left',
          ],
          'center' => [
            'title' => __( 'Center', 'shareblock-function' ),
            'icon' => 'fa fa-align-center',
          ],
          'right' => [
            'title' => __( 'Right', 'shareblock-function' ),
            'icon' => 'fa fa-align-right',
          ],
        ],
        'default' => 'center',
        'toggle' => true,
        'selectors' => [
                '{{WRAPPER}} .jl_sec_title' => 'text-align: {{VALUE}}',
            ],
      ]
    );

    $this->add_control(
            'section_upercase',
            [
                'label' => esc_html__('Title upercase', 'shareblock-function'),
                'type' => Controls_Manager::SWITCHER,
                'label_on' => esc_html__('Yes', 'shareblock-function'),
                'label_off' => esc_html__('No', 'shareblock-function'),
                'selectors'  => [
               '{{WRAPPER}} .jl_sec_title h3' => 'text-transform: uppercase !important;',               
        ],
            ]
        ); 

    $this->add_control(
            'section_hide_line',
            [
                'label' => esc_html__('Hide line', 'shareblock-function'),
                'type' => Controls_Manager::SWITCHER,
                'label_on' => esc_html__('Yes', 'shareblock-function'),
                'label_off' => esc_html__('No', 'shareblock-function'),
                'selectors'  => [
               '{{WRAPPER}} .jl_sec_title .jl_title_c:before, {{WRAPPER}} .jl_sec_title .jl_title_c:after' => 'display: none !important;',               
        ],
            ]
        );      
    
     $this->end_controls_section();
     //Title Style Section
    $this->start_controls_section(
      'section_tab_style', [
        'label'  => esc_html__( 'Post Custom Style', 'shareblock-function' ),
        'tab'     => Controls_Manager::TAB_STYLE,
      ]
        );     
 
        $this->add_control(
            'feature_style',
            [
                'label'     =>esc_html__( 'Choose Layout style', 'shareblock-function' ),
                'type'      => Controls_Manager::SELECT,
                'default'   => 'feature_1',
                'options'   => [
                        'feature_1'      =>esc_html__( 'Feature 1', 'shareblock-function' ),
                        'feature_2'      =>esc_html__( 'Feature 2', 'shareblock-function' ),
                        'feature_3'      =>esc_html__( 'Feature 3', 'shareblock-function' ),
                        'feature_4'      =>esc_html__( 'Feature 4', 'shareblock-function' ),
                        'feature_5'      =>esc_html__( 'Feature 5', 'shareblock-function' ),
                        'feature_6'      =>esc_html__( 'Feature 6', 'shareblock-function' ),
                        'feature_7'      =>esc_html__( 'Feature 7', 'shareblock-function' ),
                        'feature_8'      =>esc_html__( 'Feature 8', 'shareblock-function' ),
                        'feature_9'      =>esc_html__( 'Feature 9', 'shareblock-function' ),
                    ],
            ]
        );

      $this->add_control(
      'feature_bg',
      [
        'label' => __( 'Feature background', 'shareblock-function' ),
        'type' => \Elementor\Controls_Manager::COLOR,        
        'selectors' => [
          '{{WRAPPER}} .jl_m_below_w .jl_m_below_c' => 'background: {{VALUE}}',
        ],
        'condition' => [
            'feature_style' => 'feature_6'
        ]
      ]
    );

      $this->add_responsive_control(
        'm_font_size',
        [
            'label' => __( 'Main Title font size', 'shareblock-function' ),
            'type' => Controls_Manager::SLIDER,
            'range' => [
                'px' => [
                    'min' => 1,
                    'max' => 200,
                    'step' => 1,
                ]
            ],
            'selectors' => [
            '{{WRAPPER}} .jl_post_fr .jl_f_title,{{WRAPPER}} .jl_layout_mrw .jl_f_postbox .jl_f_title,{{WRAPPER}} .jl_m_center .text-box h3,{{WRAPPER}} .jl_mg_wrapper .jl_mg_main .entry-title,{{WRAPPER}} .jl_f_post01 .jl_f_post01_m h3,{{WRAPPER}} .jl_m_below_w .text-box .entry-title,{{WRAPPER}} .jl_mgo_wrapper .jl_mgo_main .jl_f_title,{{WRAPPER}} .jl_ov_fix.jl_mgo_wrapper.jl_ov_b .jl_mgo_main .jl_f_title' => 'font-size: {{SIZE}}{{UNIT}};',
            ],
        ]
    );

      $this->add_responsive_control(
        's_font_size',
        [
            'label' => __( 'Small Title font size', 'shareblock-function' ),
            'type' => Controls_Manager::SLIDER,
            'range' => [
                'px' => [
                    'min' => 1,
                    'max' => 200,
                    'step' => 1,
                ]
            ],
            'selectors' => [
            '{{WRAPPER}} .jl_m_right .jl_m_right_content h3,{{WRAPPER}} .jl_mg_wrapper .jl_mg_sm .entry-title,{{WRAPPER}} .jl_f_post01 .jl_f_postboxs h3,{{WRAPPER}} .jl_m_below_w .jl_mb_list .entry-title,{{WRAPPER}} .jl_mgo_wrapper .jl_mgo_sm .jl_f_title,{{WRAPPER}} .jl_ov_fix.jl_mgo_wrapper.jl_ov_b .jl_mgo_main.jl_mgo_s .jl_f_title' => 'font-size: {{SIZE}}{{UNIT}};',            
            ],
        ]
    );

      $this->add_responsive_control(
        'g_spaceing',
        [
            'label' => __( 'Grid spacing', 'shareblock-function' ),
            'type' => Controls_Manager::SLIDER,
            'default' => [
                'size' => 15,
            ],
            'range' => [
                'px' => [
                    'min' => 1,
                    'max' => 200,
                    'step' => 1,
                ]
            ],
            'selectors' => [
            '{{WRAPPER}} .jl_space .jl_spacing' => 'padding:0px {{SIZE}}{{UNIT}};',
            '{{WRAPPER}} .jl_space' => 'margin-right: -{{SIZE}}{{UNIT}}; margin-left: -{{SIZE}}{{UNIT}};',
            '{{WRAPPER}} .jl_grid_overlay .jl_sec_title' => 'padding:0px {{SIZE}}{{UNIT}};',
            ],
        ]
    ); 
    $this->add_responsive_control(
        'g_margin',
        [
            'label' => __( 'Grid Margin', 'shareblock-function' ),
            'type' => Controls_Manager::SLIDER,
            'default' => [
                'size' => 20,
            ],
            'range' => [
                'px' => [
                    'min' => 1,
                    'max' => 200,
                    'step' => 1,
                ]
            ],
            'selectors' => [
            '{{WRAPPER}} .jl_space .jl_bp, {{WRAPPER}} .jl_space .jl_sp' => 'margin-bottom: {{SIZE}}{{UNIT}};',            
            ],
        ]
    ); 

    $this->add_responsive_control(
        'sl_bgopacity',
        [
            'label' => __( 'Background opacity', 'shareblock-function' ),
            'type' => Controls_Manager::SLIDER,            
            'range' => [
                'px' => [
                    'min' => 0,
                    'max' => 1,
                    'step' => 0.1,
                ]
            ],
            'selectors' => [
            '{{WRAPPER}} .jl_f_img_link' => 'opacity: {{SIZE}};',
            ],
        ]
      );

        $this->end_controls_section();
    }

protected function render( ) { 
  $settings = $this->get_settings();

      if ( function_exists( 'shareblock_feature_right' ) ) {
      $settings['blockid'] = 'blockid_' . $this->get_id();      
      if(!empty($settings['categories'])){
      $settings['categories'] = implode(',', $settings['categories']);      
      }
      echo \shareblock_feature_right( $settings );
      }
    }

    public function post_categories() {

      $terms = get_terms( array(
            'taxonomy'    => 'category',
            'hide_empty'  => false,
            'posts_per_page' => -1, 
            'suppress_filters' => false,
      ) );

      $cat_list = [];
      foreach($terms as $post) {
      $cat_list[$post->term_id]  = [$post->name];
      }
      return $cat_list;
   }

   public function post_author() {

    $blogusers = get_users( array(
    'role__not_in' => array( 'subscriber' ),
    'fields'       => array( 'ID', 'display_name' )
    ) );

      $user_list = [];
      $user_list['none']= esc_html__( 'None', 'shareblock-function' );
      foreach($blogusers as $user) {
      $user_list[$user->ID]  = [$user->display_name];
      }
      return $user_list;
   }
}