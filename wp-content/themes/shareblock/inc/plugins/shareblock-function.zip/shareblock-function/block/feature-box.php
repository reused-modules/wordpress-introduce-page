<?php
namespace shareblockElementor\Widgets;
use Elementor\Widget_Base;
use Elementor\Controls_Manager;
use Elementor\Group_Control_Image_Size;
use Elementor\Group_Control_Typography;
use Elementor\Schemes\Color;
use Elementor\Schemes\Typography;
use Elementor\Utils;
use Elementor\Control_Media;
use Elementor\Group_Control_Border;
use Elementor\Group_Control_Box_Shadow;
use Elementor\Group_Control_Text_Shadow;
use Elementor\Group_Control_Background;
use Elementor\Repeater;
use Elementor\Icons_Manager;
if ( ! defined( 'ABSPATH' ) ) exit;

class shareblock_feature_box extends Widget_Base {

  public $base;

    public function get_name() {
        return 'shareblock-feature-box';
    }

    public function get_title() {
        return esc_html__( 'Feature Box', 'shareblock-function' );
    }

    public function get_icon() { 
        return 'eicon-gallery-justified jl-icons';
    }

    public function get_categories() {
       return [ 'shareblock-elements' ];
    }

    protected function register_controls() {

        $this->start_controls_section(
            'section_tab',
            [
                'label' => esc_html__('Feature Box Setting', 'shareblock-function'),
            ]
        );

        $repeater = new \Elementor\Repeater();        
        $repeater->add_control(
        'box_image', [
            'label' => __( 'Image', 'shareblock-function' ),
            'type' => Controls_Manager::MEDIA,
            'label_block' => true,
          ]
        );
        $repeater->add_control(
        'box_title', [
            'label' => __( 'Title', 'shareblock-function' ),
            'type' => Controls_Manager::TEXT,
            'default' => __( 'Title' , 'shareblock-function' ),
          ]
        );
        $repeater->add_control(
        'box_link', [
            'label' => __( 'Link URL', 'shareblock-function' ),
            'type' => Controls_Manager::URL,
            'default' => [
                  'url' => '',
                  'is_external' => '',
               ],
            'show_external' => true,
          ]                   
        );

        $this->add_control(
      'box_info',
      [
        'label' => __( 'Box info', 'shareblock-function' ),
        'type' => \Elementor\Controls_Manager::REPEATER,
        'fields' => $repeater->get_controls(),
        'default' => [
            [
              'box_title' => __( 'List Item 1', 'shareblock-function' ),              
            ],
            [
              'box_title' => __( 'List Item 2', 'shareblock-function' ),              
            ],
            [
              'box_title' => __( 'List Item 3', 'shareblock-function' ),              
            ],
    ],

        'title_field' => '{{{ box_title }}}',
      ]
    );    
        
      $this->add_control(
            'box_col',
            [
                'label'     =>esc_html__( 'Columns layout', 'shareblock-function' ),
                'type'      => Controls_Manager::SELECT,
                'default'   => 'd_col3',
                'options'   => [
                        'd_col3'      =>esc_html__( 'Cols 3', 'shareblock-function' ),
                        'd_col4'    =>esc_html__( 'Cols 4', 'shareblock-function' ),
                        'd_col5'    =>esc_html__( 'Cols 5', 'shareblock-function' ),
                    ],
            ]
        );  
      $this->add_control(
            'tab_box_col',
            [
                'label'     =>esc_html__( 'Tablet columns layout', 'shareblock-function' ),
                'type'      => Controls_Manager::SELECT,
                'default'   => 't_col3',
                'options'   => [
                        't_col3'      =>esc_html__( 'Cols 3', 'shareblock-function' ),
                        't_col4'    =>esc_html__( 'Cols 4', 'shareblock-function' ),
                        't_col5'    =>esc_html__( 'Cols 5', 'shareblock-function' ),
                    ],
            ]
        );  
      $this->add_responsive_control(
        'box_font_size',
        [
            'label' => __( 'Title font size', 'shareblock-function' ),
            'type' => Controls_Manager::SLIDER,
            'default' => [
                'size' => 11,
            ],
            'range' => [
                'px' => [
                    'min' => 1,
                    'max' => 200,
                    'step' => 1,
                ]
            ],
            'selectors' => [
            '{{WRAPPER}} .jl_box_info .jl_box_title' => 'font-size: {{SIZE}}{{UNIT}};',
            ],
        ]
    );
    $this->add_responsive_control(
        'box_letter_spaceing',
        [
            'label' => __( 'Title letter spacing', 'shareblock-function' ),
            'type' => Controls_Manager::SLIDER,
            'default' => [
                'size' => 0,
            ],
            'range' => [
                'px' => [
                    'min' => -20,
                    'max' => 200,
                    'step' => 1,
                ]
            ],
            'selectors' => [
            '{{WRAPPER}} .jl_box_info .jl_box_title' => 'letter-spacing: {{SIZE}}{{UNIT}} !important;',
            ],
        ]
    );  
    $this->add_responsive_control(
        'box_height',
        [
            'label' => __( 'Box height', 'shareblock-function' ),
            'type' => Controls_Manager::SLIDER,
            'range' => [
                'px' => [
                    'min' => 0,
                    'max' => 600,
                    'step' => 1,
                ]
            ],
            'selectors' => [
            '{{WRAPPER}} .jl_box_info' => 'height: {{SIZE}}{{UNIT}} !important;',
            ],
        ]
    );  

    $this->add_responsive_control(
        'box_spacing',
        [
            'label' => __( 'Box spacing between', 'shareblock-function' ),
            'type' => Controls_Manager::SLIDER,
            'range' => [
                'px' => [
                    'min' => 0,
                    'max' => 600,
                    'step' => 1,
                ]
            ],
            'selectors' => [
            '{{WRAPPER}} .jl_box_w' => 'grid-column-gap: {{SIZE}}{{UNIT}} !important;',
            ],
        ]
    );

    $this->add_responsive_control(
        'box_margin',
        [
            'label' => __( 'Box margin between', 'shareblock-function' ),
            'type' => Controls_Manager::SLIDER,
            'range' => [
                'px' => [
                    'min' => 0,
                    'max' => 600,
                    'step' => 1,
                ]
            ],
            'selectors' => [
            '{{WRAPPER}} .jl_box_w' => 'grid-row-gap: {{SIZE}}{{UNIT}} !important;',
            ],
        ]
    );  

    $this->add_control(
            'box_upercase',
            [
                'label' => esc_html__('Title Upercase', 'shareblock-function'),
                'type' => Controls_Manager::SWITCHER,
                'label_on' => esc_html__('Yes', 'shareblock-function'),
                'label_off' => esc_html__('No', 'shareblock-function'),
                'return_value' => 'yes',
                'default' => 'yes',
                'selectors'  => [
               '{{WRAPPER}} .jl_box_info .jl_box_title' => 'text-transform: uppercase !important;',               
        ],
            ]
        );    

    $this->add_control(
      'label_bg',
      [
        'label' => __( 'Label background', 'shareblock-function' ),
        'type' => \Elementor\Controls_Manager::COLOR,        
        'selectors' => [
          '{{WRAPPER}} .jl_box_info .jl_box_title' => 'background: {{VALUE}}',
        ]
      ]
    );

    $this->add_control(
      'label_color',
      [
        'label' => __( 'Label color', 'shareblock-function' ),
        'type' => \Elementor\Controls_Manager::COLOR,        
        'selectors' => [
          '{{WRAPPER}} .jl_box_info .jl_box_title' => 'color: {{VALUE}}',
        ]
      ]
    );

        $this->end_controls_section();
    }
    protected function render( ) { 
  $widget_id = $this->get_id();
  $box_info = $this->get_settings('box_info');
  $box_col = $this->get_settings('box_col');
  $tab_box_col = $this->get_settings('tab_box_col');
  if(!empty($box_info)){
    //Get all settings
    $settings = $this->get_settings();    
    $pagination = 0;?>
<div class="jl_box_c jl_clear_at">
  <div class="jl_box_w <?php echo esc_attr( $box_col ); ?> <?php echo esc_attr( $tab_box_col ); ?>">
<?php
    $counter = 1;  
    foreach ($box_info as $slide){
?>
        <div class="jl_box_info_w">
          <div class="jl_box_info jl_radus_e">
                  <?php
                  if(!empty($slide['box_title'])){
                  ?>
                  <span class="jl_box_title jl_radus_e"><?php echo esc_html($slide['box_title']); ?></span>
                <?php }?>
          <?php
            if(!empty($slide['box_link']['url']))
            {
              $target = $slide['box_link']['is_external'] ? 'target="_blank"' : '';
          ?>
              <a class="jl_box_link" href="<?php echo esc_url($slide['box_link']['url']); ?>" <?php echo esc_attr($target); ?>></a>
              <?php
            }
            // $image_url = wp_get_attachment_image_src($slide['box_image']['id'], 'thumbnail', true);
          ?>
          <div class="jl_box_bg">
            <?php echo wp_get_attachment_image($slide['box_image']['id'], 'medium', "", array( "class" => "jl_f_img_bg" ));?>
          </div>          
          </div>
          </div>          
<?php
      $counter++;
    }
?>
  </div>
</div>
<?php
  }
?>

    <?php  
    }
}