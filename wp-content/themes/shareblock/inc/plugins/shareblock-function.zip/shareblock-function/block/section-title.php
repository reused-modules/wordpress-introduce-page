<?php
namespace shareblockElementor\Widgets;
use Elementor\Widget_Base;
use Elementor\Controls_Manager;
use Elementor\Group_Control_Image_Size;
use Elementor\Group_Control_Typography;
use Elementor\Schemes\Color;
use Elementor\Schemes\Typography;
use Elementor\Utils;
use Elementor\Control_Media;
use Elementor\Group_Control_Border;
use Elementor\Group_Control_Box_Shadow;
use Elementor\Group_Control_Text_Shadow;
use Elementor\Group_Control_Background;
use Elementor\Repeater;
use Elementor\Icons_Manager;
if ( ! defined( 'ABSPATH' ) ) exit;

class shareblock_section_title extends Widget_Base {

  public $base;

    public function get_name() {
        return 'shareblock-section-title';
    }

    public function get_title() {
        return esc_html__( 'Section Title', 'shareblock-function' );
    }

    public function get_icon() { 
        return 'eicon-gallery-justified jl-icons';
    }

    public function get_categories() {
       return [ 'shareblock-elements' ];
    }

    protected function register_controls() {

        $this->start_controls_section(
            'section_tab',
            [
                'label' => esc_html__('Section Title Setting', 'shareblock-function'),
            ]
        );

        $this->add_control(
      'section_title', [
        'label'       => esc_html__( 'Section Title', 'shareblock-function' ),
        'type'        => Controls_Manager::TEXT,
        'label_block' => true,
        'default'     => 'Section title',
        'placeholder' => esc_html__( 'Section text', 'shareblock-function' )        
      ]
      );
      $this->add_control(
      'section_sub_title', [
        'label'       => esc_html__( 'Section Sub Title', 'shareblock-function' ),
        'type'        => Controls_Manager::TEXT,
        'label_block'   => true,
      ]
      );
        
      $this->add_control(
            'section_style',
            [
                'label'     =>esc_html__( 'Section Title Styles', 'shareblock-function' ),
                'type'      => Controls_Manager::SELECT,
                'default'   => 'sec_style1',
                'options'   => [
                        'sec_style1'      =>esc_html__( 'Style 1', 'shareblock-function' ),
                        'sec_style2'    =>esc_html__( 'Style 2', 'shareblock-function' ),
                        'sec_style3'    =>esc_html__( 'Style 3', 'shareblock-function' ),
                    ],
            ]
        );  
      $this->add_responsive_control(
        'sec_font_size',
        [
            'label' => __( 'Title font size', 'shareblock-function' ),
            'type' => Controls_Manager::SLIDER,
            'default' => [
                'size' => 23,
            ],
            'range' => [
                'px' => [
                    'min' => 1,
                    'max' => 200,
                    'step' => 1,
                ]
            ],
            'selectors' => [
            '{{WRAPPER}} .cus_sec_title h3' => 'font-size: {{SIZE}}{{UNIT}};',
            ],
        ]
    );
    $this->add_responsive_control(
        'sec_letter_spaceing',
        [
            'label' => __( 'Title letter spacing', 'shareblock-function' ),
            'type' => Controls_Manager::SLIDER,
            'default' => [
                'size' => 0,
            ],
            'range' => [
                'px' => [
                    'min' => 0,
                    'max' => 200,
                    'step' => 1,
                ]
            ],
            'selectors' => [
            '{{WRAPPER}} .cus_sec_title h3' => 'letter-spacing: {{SIZE}}{{UNIT}} !important;',
            ],
        ]
    );
    $this->add_control(
      'title_color',
      [
        'label' => __( 'Title color', 'shareblock-function' ),
        'type' => \Elementor\Controls_Manager::COLOR,        
        'selectors' => [
          '{{WRAPPER}} .cus_sec_title h3' => 'color: {{VALUE}}',
        ],
      ]
    );
    $this->add_control(
      'sub_title_color',
      [
        'label' => __( 'Sub title color', 'shareblock-function' ),
        'type' => \Elementor\Controls_Manager::COLOR,        
        'selectors' => [
          '{{WRAPPER}} .cus_sec_title p' => 'color: {{VALUE}}',
        ],
      ]
    );
    $this->add_control(
      'line_color',
      [
        'label' => __( 'Line color', 'shareblock-function' ),
        'type' => \Elementor\Controls_Manager::COLOR,
        'selectors' => [
          '{{WRAPPER}} .cus_sec_title.sec_style2 h3:after' => 'border-bottom: 4px solid {{VALUE}}',
          '{{WRAPPER}} .cus_sec_title.sec_style3 h3 span:before, {{WRAPPER}} .cus_sec_title.sec_style3 h3 span:after' => 'border-bottom: 1px solid {{VALUE}}',
        ],
      ]
    );
    $this->add_control(
      'section_align',
      [
        'label' => __( 'Alignment', 'shareblock-function' ),
        'type' => \Elementor\Controls_Manager::CHOOSE,
        'options' => [
          'left' => [
            'title' => __( 'Left', 'shareblock-function' ),
            'icon' => 'fa fa-align-left',
          ],
          'center' => [
            'title' => __( 'Center', 'shareblock-function' ),
            'icon' => 'fa fa-align-center',
          ],
          'right' => [
            'title' => __( 'Right', 'shareblock-function' ),
            'icon' => 'fa fa-align-right',
          ],
        ],
        'default' => 'center',
        'toggle' => true,
        'selectors' => [
                '{{WRAPPER}} .cus_sec_title' => 'text-align: {{VALUE}}',
            ],
      ]
    );

    $this->add_control(
            'section_upercase',
            [
                'label' => esc_html__('Title Upercase', 'shareblock-function'),
                'type' => Controls_Manager::SWITCHER,
                'label_on' => esc_html__('Yes', 'shareblock-function'),
                'label_off' => esc_html__('No', 'shareblock-function'),
                'selectors'  => [
               '{{WRAPPER}} .cus_sec_title h3' => 'text-transform: uppercase !important;',               
        ],
            ]
        );      
        $this->end_controls_section();
    }
    protected function render( ) { 
        $settings = $this->get_settings_for_display();
        $this->add_inline_editing_attributes( 'section_title', 'none' );
        $this->add_inline_editing_attributes( 'section_sub_title', 'none' );
        $section_style = $settings['section_style'];
        if ( empty( $settings['section_style'] ) ) {
        $section_style = 'sec_style1';        
        }
        
        ?>
          <div class="cus_sec_title <?php echo esc_attr( $section_style ); ?>">
          <?php if(!empty($settings['section_title'])){?>
          <h3><span <?php echo $this->get_render_attribute_string( 'section_title' ); ?>><?php echo esc_html($settings['section_title']); ?></span></h3>
          <?php }?>
          <?php if(!empty($settings['section_sub_title'])){?>
          <p <?php echo $this->get_render_attribute_string( 'section_sub_title' ); ?>><?php echo esc_html($settings['section_sub_title']); ?></p>
          <?php }?>
          </div>                    
    <?php  
    }    
}