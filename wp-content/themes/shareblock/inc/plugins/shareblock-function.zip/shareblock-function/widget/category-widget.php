<?php
if ( ! defined( 'ABSPATH' ) ) exit;
add_action('widgets_init','shareblock_category_widget');


function shareblock_category_widget(){
		register_widget("shareblock_category_image_widget_register");
}

class shareblock_category_image_widget_register extends WP_widget{

/*-----------------------------------------------------------------------------------*/
/*	Widget Setup
/*-----------------------------------------------------------------------------------*/

	public function __construct() {
		$widget_ops = array( 'classname' => 'jellywp_cat_image', 'description' => esc_html__( 'Dispaly Category With Image' , 'shareblock-function') );
		parent::__construct('shareblock_category_image_widget_register', esc_html__('jellywp: Category Image', 'shareblock-function'), $widget_ops);
	}

/*-----------------------------------------------------------------------------------*/
/*	Display Widget
/*-----------------------------------------------------------------------------------*/
	
	function widget($args,$instance){
	extract($args);		
		
		$title = isset($instance['title']) ? $instance['title']: "Display Category With image";
		$number_of_cat = isset($instance['number_of_cat']) ? $instance['number_of_cat']: "4";
		$cat_id = isset($instance['cat_id']) ? $instance['cat_id']: "";
		$columns = isset($instance['columns']) ? $instance['columns']: "column1";
		$cat_styles = isset($instance['cat_styles']) ? $instance['cat_styles']: "style1";

		
		print $before_widget;
        if ( $title ){ 
        print $before_title . esc_attr($title) . $after_title; 
        }
		?>

<div class="wrapper_category_image jl_clear_at <?php echo esc_attr($columns); echo ' '.esc_attr($cat_styles); ?>">
    <?php

    		if($cat_id){$cat_id = explode(",",$cat_id);}else{$cat_id = "";}
			$args = array(
		    'orderby'       => 'include', 
			'order'         => 'ASC',
			'hide_empty'    => false,
		    'fields'        => 'all',
		    'pad_counts'    => false, 
		    'include'       => $cat_id,
		    'number'        => $number_of_cat,
		    );
			$categories = get_terms('category', $args);
			if ($categories) {
            echo '<div class="category_image_wrapper_main">';
            foreach( $categories as $tag) {
              $tag_link = get_category_link($tag->term_id);
              $title_bgcolor = get_term_meta($tag->term_id, "category_bgcolor_options", true);
              $category_image_main = get_term_meta($tag->term_id, "jelly_cat_header_image_id", true);              
				echo '<div class="jl_cat_img_w"><div class="jl_cat_img_c">';
				echo '<a class="category_image_link" id="category_color_'.$tag->term_id.'" href="'.esc_url($tag_link).'"></a>';
				$jelly_header_id = absint( get_term_meta( $tag->term_id, 'jelly_header_id', true ) );
				if ($jelly_header_id){
				echo wp_get_attachment_image( $jelly_header_id, 'shareblock_featuresmall', "", array( "class" => "category_image_bg_image jl_f_img_bg" ) );				
				}
             echo '<span class="jl_cm_overlay"><span class="jl_cm_name">'.$tag->name.'</span><span class="jl_cm_count"  style="background-color: '.$title_bgcolor.';">'.$tag->count.'</span></span>';
            echo '</div></div>';
            }
            echo "</div>";
            }
			?>
    <?php
		print $after_widget;
		echo "</div>";
	}

/*-----------------------------------------------------------------------------------*/
/*	Update Widget
/*-----------------------------------------------------------------------------------*/
	
	function update($new_instance, $old_instance){
		$instance = $old_instance;
		
		$instance['title'] = $new_instance['title'];
		$instance['number_of_cat'] = $new_instance['number_of_cat'];
		$instance['cat_id'] = $new_instance['cat_id'];
		$instance['columns'] = $new_instance['columns'];
		$instance['cat_styles'] = $new_instance['cat_styles'];

		return $instance;
	}



	function form($instance){
		?>
    <?php
			$defaults = array( 'title' => esc_html__( 'Categories' , 'shareblock-function'), 'columns' => 'column1', 'cat_styles' => 'style1', 'number_of_cat' => '4', 'cat_id' => '');
			$instance = wp_parse_args((array) $instance, $defaults); 
		?>

    <p>
        <label for="<?php echo esc_attr($this->get_field_id('title')); ?>">
            <?php esc_html_e( 'Title:', 'shareblock-function'); ?></label>
        <input class="widefat" width="100%" id="<?php echo esc_attr($this->get_field_id('title')); ?>" name="<?php echo esc_attr($this->get_field_name('title')); ?>" type="text" value="<?php echo esc_attr($instance['title']); ?>" />
    </p>

    <p>
		<label for="<?php echo esc_attr($this->get_field_id('columns')); ?>"><?php esc_html_e( 'Columns Layout', 'shareblock-function' ); ?>:</label> 
		<select id="<?php echo esc_attr($this->get_field_id('columns')); ?>" name="<?php echo esc_attr($this->get_field_name('columns')); ?>" class="widefat categories" style="width:100%;">
			<option value='column1' <?php if ('column1' == $instance['columns']) echo 'selected="selected"'; ?>><?php esc_html_e( '1 Column', 'shareblock-function' ); ?></option>
			<option value='column2' <?php if ('column2' == $instance['columns']) echo 'selected="selected"'; ?>><?php esc_html_e( '2 Columns', 'shareblock-function' ); ?></option>
			<option value='column3' <?php if ('column3' == $instance['columns']) echo 'selected="selected"'; ?>><?php esc_html_e( '3 Columns', 'shareblock-function' ); ?></option>
			<option value='column4' <?php if ('column4' == $instance['columns']) echo 'selected="selected"'; ?>><?php esc_html_e( '4 Columns', 'shareblock-function' ); ?></option>
			<option value='column5' <?php if ('column5' == $instance['columns']) echo 'selected="selected"'; ?>><?php esc_html_e( '5 Columns', 'shareblock-function' ); ?></option>
			<option value='column6' <?php if ('column6' == $instance['columns']) echo 'selected="selected"'; ?>><?php esc_html_e( '6 Columns', 'shareblock-function' ); ?></option>
		</select>
		</p>

	<p>
		<label for="<?php echo esc_attr($this->get_field_id('cat_styles')); ?>"><?php esc_html_e( 'Style', 'shareblock-function' ); ?>:</label> 
		<select id="<?php echo esc_attr($this->get_field_id('cat_styles')); ?>" name="<?php echo esc_attr($this->get_field_name('cat_styles')); ?>" class="widefat categories" style="width:100%;">
			<option value='style1' <?php if ('style1' == $instance['cat_styles']) echo 'selected="selected"'; ?>><?php esc_html_e( 'Style 1', 'shareblock-function' ); ?></option>
			<option value='style2' <?php if ('style2' == $instance['cat_styles']) echo 'selected="selected"'; ?>><?php esc_html_e( 'Style 2', 'shareblock-function' ); ?></option>
			<option value='style3' <?php if ('style3' == $instance['cat_styles']) echo 'selected="selected"'; ?>><?php esc_html_e( 'Style 3', 'shareblock-function' ); ?></option>			
		</select>
		</p>

    <p>
        <label for="<?php echo esc_attr($this->get_field_id('number_of_cat')); ?>">
            <?php esc_html_e( 'Number Of Category:', 'shareblock-function'); ?></label>
        <input class="widefat" width="100%" id="<?php echo esc_attr($this->get_field_id('number_of_cat')); ?>" name="<?php echo esc_attr($this->get_field_name('number_of_cat')); ?>" type="text" value="<?php echo esc_attr($instance['number_of_cat']); ?>" />
    </p>
    <p>
        <label for="<?php echo esc_attr($this->get_field_id('cat_id')); ?>">
            <?php esc_html_e( 'Category id EX: 1,2,3', 'shareblock-function'); ?></label>
        <input class="widefat" width="100%" id="<?php echo esc_attr($this->get_field_id('cat_id')); ?>" name="<?php echo esc_attr($this->get_field_name('cat_id')); ?>" type="text" value="<?php echo esc_attr($instance['cat_id']); ?>" />
    </p>


    <?php

	}
}
?>