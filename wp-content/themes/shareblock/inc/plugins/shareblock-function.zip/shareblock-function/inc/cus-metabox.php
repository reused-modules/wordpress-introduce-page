<?php
if ( ! defined( 'ABSPATH' ) ) exit;
	class shareblock_Meta_Box{
		
		protected $_metabox;
		
		function __construct( $metabox ) {
			if ( !is_admin() ) return;
	
			$this->_metabox = $metabox;
	
			add_action( 'admin_menu', array( &$this, 'add' ) );
			add_action( 'save_post', array( &$this, 'save' ) );
	
		}
		
		// Add metaboxes
		function add() {
			$this->_metabox['context'] = empty($this->_metabox['context']) ? 'normal' : $this->_metabox['context'];
			$this->_metabox['priority'] = empty($this->_metabox['priority']) ? 'high' : $this->_metabox['priority'];
			
			foreach ( $this->_metabox['pages'] as $page ) {
				add_meta_box( $this->_metabox['id'], $this->_metabox['title'], array(&$this, 'show'), $page, $this->_metabox['context'], $this->_metabox['priority']) ;
			}
		}
		
		// Show fields
		function show() {
			global $post;
			
			echo '<input type="hidden" name="wp_meta_box_nonce" value="', wp_create_nonce( basename(__FILE__) ), '" />';
			echo '<div class="jl_tabbox_wrapper">';
			
			if ( get_post_type( get_the_ID() ) == 'post' ) {
			echo '
			<div class="jl_nab_tab">
	        <a id="options-group-1-tab" class="generalsetting-tab" title="General Setting" href="#options-group-1">'.esc_html__('Post Settings', 'shareblock-function').'</a>
	        <a id="options-group-2-tab" class="generalsetting-tab" title="General Setting" href="#options-group-2">'.esc_html__('Post Review', 'shareblock-function').'</a>
	        <a id="options-group-3-tab" class="generalsetting-tab" title="General Setting" href="#options-group-3">'.esc_html__('Post Format gallery', 'shareblock-function').'</a>
	        <a id="options-group-4-tab" class="generalsetting-tab" title="General Setting" href="#options-group-4">'.esc_html__('Post Format quote', 'shareblock-function').'</a>
	        <a id="options-group-5-tab" class="generalsetting-tab" title="General Setting" href="#options-group-5">'.esc_html__('Post Format video', 'shareblock-function').'</a>
	        <a id="options-group-6-tab" class="generalsetting-tab" title="General Setting" href="#options-group-6">'.esc_html__('Post Format audio', 'shareblock-function').'</a>
	        </div>
	    	';
			}
			if ( get_post_type( get_the_ID() ) == 'page' ) {
			echo '
			<div class="jl_nab_tab">
	        <a id="options-group-1-tab" class="generalsetting-tab" title="General Setting" href="#options-group-1">'.esc_html__('Page Header', 'shareblock-function').'</a>	        
	        <a id="options-group-2-tab" class="generalsetting-tab" title="General Setting" href="#options-group-2">'.esc_html__('Page Settings', 'shareblock-function').'</a>	        
	        </div>
	    	';
			}
			
			foreach ( $this->_metabox['fields'] as $field ) {
				
				if ( !isset( $field['name'] ) ) $field['name'] = '';
				if ( !isset( $field['desc'] ) ) $field['desc'] = '';
				if ( !isset( $field['std'] ) ) $field['std'] = '';
			
				// get value of this field if it exists for this post
				$meta = get_post_meta($post->ID, $field['id'], true);
				
				// Use standard value if empty
				$meta = ( '' === $meta || array() === $meta ) ? $field['std'] : $meta;
				
				// begin a table row with
				echo '<div class="jl_trow group" id="'.$field['id'].'">';
					echo '<div class="jl_th"><label for="input-'.$field['id'].'">'.$field['label'].'</label></div>';
					
					echo '<div class="jl_td">';
					switch($field['type']) {						
						
						case 'text':
							echo '<input type="text" name="'.$field['id'].'" id="input-'.$field['id'].'" value="'.$meta.'" size="64" />';
							echo '<br /><span style="margin-top: 0px; display: block;" class="description">'.$field['desc'].'</span>';
							break;
						case 'image':
							echo '<input id="jelly_cat_header_image_id" type="hidden" name="'.$field['id'].'" id="'.$field['id'].'" value="'.$meta.'" size="64" />';
							echo '<span style="margin-top: 0px; display: block;" class="description">'.$field['desc'].'</span>';
							echo '<div id="jelly_cat_header" style="margin-bottom:10px; width: 100px;">';
							if(!empty($meta)){
							$review_img = wp_get_attachment_image_src($meta, 'medium');
							if(!empty($review_img)){
							echo '<img src="'.$review_img[0].'" style="max-width: 100px;"/>';
							}
							}else{
							echo '<img src="'.esc_url(plugin_dir_url( __FILE__ ).'asset/images/none_image.png').'" style="max-width: 100px;"/>';
							}
							echo'</div>';
							echo '<button type="submit" class="jelly_upload_header jladdbtn">'.esc_html__('Add Media', 'shareblock-function').'</button>';
							echo '<button type="submit" class="jelly_remove_header jlremovebtn">'.esc_html__('Remove Media', 'shareblock-function').'</button>';
							break;
						case 'color':
							echo '<input type="text" class="colorpicker" name="'.$field['id'].'" id="input-'.$field['id'].'" value="'.$meta.'" size="64" />';
							echo '<br /><span style="margin-top: 0px; display: block;" class="description">'.$field['desc'].'</span>';
							break;
						case 'line':							
							echo '<span style="margin-top: 0px; display: block;" class="description">'.$field['desc'].'</span>';							
							break;		
						case 'topen':							
							echo '<div id="'.$field['id'].'">';
							break;		
						case 'tclose':							
							echo '</div>';							
							break;		
						case 'gallery':
							echo '<br /><span style="margin-top: 0px; display: block;" class="description">'.$field['desc'].'</span>';
							?>
							<ul class="jlmedia-gallery-images-holder clearfix">
								<?php
								$image_gallery_val = get_post_meta( $post->ID, $field['id'], true);
								if($image_gallery_val!='' ) $image_gallery_array=explode(',',$image_gallery_val);

								if(isset($image_gallery_array) && count($image_gallery_array)!=0):

									foreach($image_gallery_array as $gimg_id):
										$gimage_wp = wp_get_attachment_image_src($gimg_id,'thumbnail', true);
										echo '<li class="jlmedia-gallery-image-holder"><img src="'.esc_url($gimage_wp[0]).'"/></li>';

									endforeach;

								endif;
								?>
							</ul>
							<input type="hidden" value="<?php echo esc_attr($image_gallery_val); ?>" id="<?php echo esc_attr( $field['id']) ?>" name="<?php echo esc_attr( $field['id']) ?>">
							<div class="jlmedia-gallery-uploader">
								<a class="jlmedia-gallery-upload-btn btn btn-sm btn-primary"
								   href="javascript:void(0)"><?php esc_html_e('Upload or Edit', 'shareblock-function'); ?></a>
								<a class="jlmedia-gallery-clear-btn btn btn-sm btn-default pull-right"
								   href="javascript:void(0)"><?php esc_html_e('Remove All', 'shareblock-function'); ?></a>
							</div>
							<?php
							break;
						case 'textarea':
							echo '<textarea name="'.$field['id'].'" id="input-'.$field['id'].'" cols="60" rows="4">'.$meta.'</textarea>';
							echo '<br /><span style="margin-top: 0px; display: block;" class="description">'.$field['desc'].'</span>';
							break;
						case 'checkbox':
							echo '<input style="margin-right: 10px;" type="checkbox" name="'.$field['id'].'" id="input-'.$field['id'].'" ',$meta ? ' checked="checked"' : '','/>';
							echo '<label for="input-'.$field['id'].'">'.$field['desc'].'</label>';
							break;
						case 'select':
							echo '<select name="'.$field['id'].'" id="input-'.$field['id'].'">';
							foreach ($field['options'] as $key => $val) {
								echo '<option', $meta == $key ? ' selected="selected"' : '', ' value="'.$key.'">'.$val.'</option>';
							}
							echo '</select><br /><span style="margin-top: 0px; display: block;" class="description">'.$field['desc'].'</span>';
							break;
						case 'radio':
							foreach ( $field['options'] as $key => $val ) {
								echo '<input type="radio" name="'.$field['id'].'" id="input-'.$field['id'].'_'.$key.'" value="'.$key.'" ',$meta == $key ? ' checked="checked"' : '',' />';
								echo '<label for="'.$field['id'].'_'.$key.'">'.$val.'</label><br>';
							}
							break;
						case 'rating_criteria':
                            
                            $rows = array();
                            if($meta) $rows = $meta;
                            $c = 0;
                            if ( count( $rows ) > 0 ) {
                                foreach( $rows as $row ) {
                                    if ( isset( $row['c_label'] ) || isset( $row['score'] ) ) {
                                        echo '
                                        <p class="rating_row" style="margin-bottom:10px;">
                                        <label for="'.$field['id'].'['.$c.'][c_label]">'.esc_html__('Label :', 'shareblock-function').'</label> 
                                        <input type="text" name="'.$field['id'].'['.$c.'][c_label]" value="'.$row['c_label'].'" />
                                        <label for="'.$field['id'].'['.$c.'][score]">'.esc_html__('Score :', 'shareblock-function').'</label> 
                                        <input type="text" name="'.$field['id'].'['.$c.'][score]" value="'.$row['score'].'" />
                                        <a class="remove_review button-secondary">'.esc_html__('Remove', 'shareblock-function').'</a>
                                        </p>';
                                        $c = $c + 1;
                                    }
                                }
                            }
                            echo '<span id="criteria-placeholder"></span>';
                            echo '<a class="add-criteria button-primary" href="#">'.esc_html__('Add Criteria', 'shareblock-function').'</a>';
                            echo '<br /><span style="margin-top: 0px; display: block;" class="description">'.$field['desc'].'</span>';
                            ?>
                            <script>
                                var $ = jQuery.noConflict();
                                $(document).ready(function() {
                                    var count = <?php echo esc_attr($c); ?>;
                                    $('.add-criteria').click(function() {
                                        count = count + 1;                                
                                        $('#criteria-placeholder').append('<p class="rating_row" style="margin-bottom:10px;"><label for="<?php echo esc_attr($field['id']); ?>['+count+'][c_label]">'.esc_html__('Label :', 'shareblock-function').' </label><input type="text" name="<?php echo esc_attr($field['id']); ?>['+count+'][c_label]" value="" /><label for="<?php echo esc_attr($field['id']); ?>['+count+'][score]"> '.esc_html__('Score :', 'shareblock-function').' </label><input type="text" name="<?php echo esc_attr($field['id']); ?>['+count+'][score]" value="" /> <a class="remove_review button-secondary">'.esc_html__('Remove', 'shareblock-function').'</a></p>');
                                        return false;
                                    });
                                    
                                    $('body').on('click', '.remove_review', function(){
                                        $(this).parent('.rating_row').remove();
                                    });                                 
                                    
                                });
                            </script>
                            <?php
                        break; 
						
					}
					echo '</div>';
				echo '</div>';
				
			}
			
			echo '</div>';
		}
		

		// Save data from metabox
		function save( $post_id)  {
			// verify nonce
			if ( ! isset( $_POST['wp_meta_box_nonce'] ) || !wp_verify_nonce( $_POST['wp_meta_box_nonce'], basename(__FILE__) ) ) {
				return $post_id;
			}
			
			// check autosave
			if (defined('DOING_AUTOSAVE') && DOING_AUTOSAVE)
				return $post_id;
				
			// check permissions
			if ('page' == $_POST['post_type']) {
				if (!current_user_can('edit_page', $post_id))
					return $post_id;
				} elseif (!current_user_can('edit_post', $post_id)) {
					return $post_id;
			}
			
			// loop through fields and save the data
			foreach ( $this->_metabox['fields'] as $field ) {
				
				$old = get_post_meta($post_id, $field['id'], true);
				
				$new = isset( $_POST[$field['id']] ) ? $_POST[$field['id']] : null;
				
				if ($new && $new != $old) {
					update_post_meta($post_id, $field['id'], $new);
				} 
				elseif ('' == $new && $old) {
					delete_post_meta($post_id, $field['id'], $old);
				}
				
			} // end foreach
		}
	}
	


/*	Initialize Metabox
 *	--------------------------------------------------------- */
	function shareblock_init_metaboxes() {
		if ( class_exists( 'shareblock_Meta_Box' ) ) {
	
	

//// user metabox field
add_filter( 'shareblock_meta_metaboxes', 'shareblock_meta_metaboxes' );
	
function shareblock_meta_metaboxes( array $metaboxes ) {	

	$option_sidebar = array();
	$sidebars = get_option('sbg_sidebars');
	$option_sidebar['default']= esc_html__( 'Default Sidebar', 'shareblock-function' );
	if(isset($sidebars)) {
		if(is_array($sidebars)) {
			foreach($sidebars as $sidebar) {
				$sidebar_lower = strtolower($sidebar);
				$sidebarid = str_replace(' ','-', $sidebar_lower);
				$option_sidebar[$sidebarid] = $sidebar;
			}			
		}
	}
	


		$metaboxes[] = array(
			'id'		 => 'jl_single_post_layouts',
			'title'      => esc_html__('Single Post Options', 'shareblock-function'),
			'pages'      => array('post'), // Post type
			'context'    => 'normal',
			'priority'   => 'high',
			'fields' => array(
				
				// tab open
                array(
					'label' => "",
					'id'	=> 'options-group-1',
					'type'	=> 'topen'
				),
                // tab open

                array(
					'label' => esc_html__('Enable Full Post', 'shareblock-function'),
					'desc'	=> esc_html__('Check this to enable single post content full.', 'shareblock-function'),
					'id'	=> 'single_post_full_single_post_full',
					'type'	=> 'checkbox'
				),

				array(
					'label' => esc_html__('Post Subtitle', 'shareblock-function'),
					'id'	=> 'single_post_subtitle',
					'type'	=> 'text'
				),				
				array(
					'label' => esc_html__('Select Post Layout', 'shareblock-function'),
					'desc'	=> '',
					'id'	=> 'single_post_layout',
					'std' => '',
					'type'	=> 'select',
					'options' => array (
						'' => esc_html__('Default Layout', 'shareblock-function'),
						's_post_layout_1' => esc_html__('Post Layout 1', 'shareblock-function'),
						's_post_layout_2' => esc_html__('Post Layout 2', 'shareblock-function'),
						's_post_layout_3' => esc_html__('Post Layout 3', 'shareblock-function'),
						's_post_layout_4' => esc_html__('Post Layout 4', 'shareblock-function'),
						's_post_layout_5' => esc_html__('Post Layout 5', 'shareblock-function'),
						's_post_layout_6' => esc_html__('Post Layout 6', 'shareblock-function'),
						's_post_layout_7' => esc_html__('Post Layout 7', 'shareblock-function'),
						's_post_layout_8' => esc_html__('Post Layout 8', 'shareblock-function'),
						)
				),
				array(
					'label' => esc_html__('Post sidebar', 'shareblock-function'),
					'desc'	=> '',
					'id'	=> 'single_post_sidebar',
					'std' => '',
					'type'	=> 'select',
					'options' => $option_sidebar
				),
				array(
					'label' => esc_html__('Fake share count', 'shareblock-function'),
					'id'	=> 'single_fake_counter',
					'type'	=> 'text'
				),	

                // tab close
				array(
					'label' => "",
					'id'	=> 'post_option_close',
					'type'	=> 'tclose'
				),
				// tab close

				// tab open
                array(
					'label' => "",
					'id'	=> 'options-group-2',
					'type'	=> 'topen'
				),
                // tab open

                array(
                    'label' => esc_html__('Enable Review', 'nanopress'),
                    'desc'  => esc_html__('Check this to enable review', 'shareblock-function'),
                    'id'    => 'single_post_review',
                    'type'  => 'checkbox'
                ),
                array(
                    'label' => esc_html__('Rating Criteria', 'shareblock-function'),
                    'desc'  => esc_html__('Label : A name of criteria - Score : A number value between 0 - 10, incerement 0.1', 'shareblock-function'),
                    'id'    => 'rating_criteria',
                    'type'  => 'rating_criteria'
                ),
                array(
                    'label' => esc_html__('Rating Type', 'shareblock-function'),
                    'id'    => 'rating_type',
                    'type'  => 'select',
                    'options' => array ( 'star' => 'Star', 'number' => 'Number', 'letter' => 'Letter Grade', 'percent' => 'Percentage')
                ),
                array(
						'label' => esc_html__('Review Image', 'shareblock-function'),
						'desc'	=> "",
						'id'	=> 'review_image',
						'type'	=> 'image',
						'std'	=> ''
					),
                array(
                    'label' => esc_html__('Review color', 'shareblock-function'),
                    'id'    => 'review_color',
                    'type'  => 'color',
                    'std'   => ''
                ),
                array(
                    'label' => esc_html__('Review Title', 'shareblock-function'),
                    'id'    => 'review_box_title',
                    'type'  => 'text',
                    'std'   => 'Review Overview'
                ),
                array(
                    'label' => esc_html__('Summary', 'shareblock-function'),
                    'desc'  => esc_html__('Summary in review box', 'shareblock-function'),
                    'id'    => 'review_summary',
                    'type'  => 'textarea',
                    'std'   => ''
                ),
                array(
                    'label' => esc_html__('Positives', 'shareblock-function'),
                    'desc'  => esc_html__('Positives review each line in review box.', 'shareblock-function'),
                    'id'    => 'review_pos',
                    'type'  => 'textarea',
                    'std'   => ''
                ),
                array(
                    'label' => esc_html__('Negatives', 'shareblock-function'),
                    'desc'  => esc_html__('Negatives review each line in review box', 'shareblock-function'),
                    'id'    => 'review_neg',
                    'type'  => 'textarea',
                    'std'   => ''
                ),

                // tab close
				array(
					'label' => "",
					'id'	=> 'review_close',
					'type'	=> 'tclose'
				),
				// tab close



				// tab open
                array(
					'label' => "",
					'id'	=> 'options-group-3',
					'type'	=> 'topen'
				),
                // tab open

                // gallery
				array(
					'label' => esc_html__('gallery', 'shareblock-function'),
					'id'	=> 'gallery_post_format',
					'type'	=> 'gallery'
				),

				// tab close
				array(
					'label' => "",
					'id'	=> 'post_option_close',
					'type'	=> 'tclose'
				),
				// tab close

				// tab open
                array(
					'label' => "",
					'id'	=> 'options-group-4',
					'type'	=> 'topen'
				),
                // tab open			

				// quote
				array(
					'label' => esc_html__('Quote title', 'shareblock-function'),
					'id'	=> 'quote_post_title',
					'type'	=> 'textarea'
				),
				array(
					'label' => esc_html__('Quote author', 'shareblock-function'),
					'id'	=> 'quote_post_author',
					'type'	=> 'text'
				),

				// tab close
				array(
					'label' => "",
					'id'	=> 'post_option_close',
					'type'	=> 'tclose'
				),
				// tab close

				// tab open
                array(
					'label' => "",
					'id'	=> 'options-group-5',
					'type'	=> 'topen'
				),
                // tab open

				// video
				array(
					'label' => esc_html__('Video Embed', 'shareblock-function'),
					'id'	=> 'video_post_embed',
					'type'	=> 'textarea'
				),
				array(
					'label' => esc_html__('Video link', 'shareblock-function'),
					'id'	=> 'video_post_link',
					'type'	=> 'text'
				),		

				// tab close
				array(
					'label' => "",
					'id'	=> 'post_option_close',
					'type'	=> 'tclose'
				),
				// tab close

				// tab open
                array(
					'label' => "",
					'id'	=> 'options-group-6',
					'type'	=> 'topen'
				),
                // tab open		

				// audio
				array(
					'label' => esc_html__('Audio Embed', 'shareblock-function'),
					'id'	=> 'auto_post_embed',
					'type'	=> 'textarea'
				),
				array(
					'label' => esc_html__('Audio link', 'shareblock-function'),
					'id'	=> 'auto_post_link',
					'type'	=> 'text'
				),

				// tab close
				array(
					'label' => "",
					'id'	=> 'post_format_close',
					'type'	=> 'tclose'
				),
				// tab close


							
			)
		);


$metaboxes[] = array(
			'id'		 => 'jl_option_page',
			'title'      => esc_html__('Page options', 'shareblock-function'),
			'pages'      => array('page'), // Post type
			'context'    => 'normal',
			'priority'   => 'high',
			'fields' => array(

				// tab open
                array(
					'label' => "",
					'id'	=> 'options-group-1',
					'type'	=> 'topen'
				),
                // tab open

				array(
					'label' => esc_html__('Select page header', 'shareblock-function'),
					'desc'	=> '',
					'id'	=> 'custom_header_layout',
					'std' => '',
					'type'	=> 'select',
					'options' => array (
						'' => esc_html__('Default Header', 'shareblock-function'),
						'header_1' => esc_html__('Header Layout 1', 'shareblock-function'),
						'header_2' => esc_html__('Header Layout 2', 'shareblock-function'),
						'header_3' => esc_html__('Header Layout 3', 'shareblock-function'),
						'header_4' => esc_html__('Header Layout 4', 'shareblock-function'),
						'header_5' => esc_html__('Header Layout 5', 'shareblock-function'),
						'header_6' => esc_html__('Header Layout 6', 'shareblock-function'),
						)
				),
				array(
					'label' => esc_html__('Logo size', 'shareblock-function'),
					'id'	=> 'jl_logo_size',
					'desc'  => esc_html__('Custom logo size for this page Ex: 70px', 'shareblock-function'),
					'type'	=> 'text'					
				),
				array(
					'label' => esc_html__('Transparent header', 'shareblock-function'),
					'desc'	=> esc_html__('Check this to remove background header', 'shareblock-function'),
					'id'	=> 'jl_header_tp',
					'type'	=> 'checkbox'
				),
				array(
					'label' => esc_html__('Hide promo top bar', 'shareblock-function'),
					'desc'	=> esc_html__('Check this to hide top bar for this page', 'shareblock-function'),
					'id'	=> 'jl_hide_topbar',
					'type'	=> 'checkbox'
				),
				array(
					'label' => esc_html__('Hide menu', 'shareblock-function'),
					'desc'	=> esc_html__('Check this to hide menu', 'shareblock-function'),
					'id'	=> 'jl_hide_menu',
					'type'	=> 'checkbox'
				),
				array(
					'label' => esc_html__('Half screen header', 'shareblock-function'),
					'desc'	=> esc_html__('Check this make header half screen', 'shareblock-function'),
					'id'	=> 'jl_half_screen',
					'type'	=> 'checkbox'
				),

				// tab close
				array(
					'label' => "",
					'id'	=> 'post_option_close',
					'type'	=> 'tclose'
				),
				// tab close

				// tab open
                array(
					'label' => "",
					'id'	=> 'options-group-2',
					'type'	=> 'topen'
				),
                // tab open


				array(
					'label' => esc_html__('Hide footer', 'shareblock-function'),
					'desc'	=> esc_html__('Check this to hide footer', 'shareblock-function'),
					'id'	=> 'jl_hide_footer',
					'type'	=> 'checkbox'
				),
				array(
					'label' => esc_html__('Body Padding', 'shareblock-function'),
					'id'	=> 'jl_page_padding',
					'desc'  => esc_html__('Page body padding Ex: 70px', 'shareblock-function'),
					'type'	=> 'text'					
				),
				array(
					'label' => esc_html__('Body Background', 'shareblock-function'),
					'id'	=> 'jl_body_bg',
					'type'	=> 'color'
				),

                // tab close
				array(
					'label' => "",
					'id'	=> 'post_header_close',
					'type'	=> 'tclose'
				),
				// tab close
				
			)
		);
		
		
	return $metaboxes;
}
//// end user metabox field
			$metaboxes = array();
			$metaboxes = apply_filters ( 'shareblock_meta_metaboxes' , $metaboxes );
			foreach ( $metaboxes as $metabox ) {
				$my_box = new shareblock_Meta_Box( $metabox );
			}
		}
	}
	
	add_action( 'init', 'shareblock_init_metaboxes', 9999 );